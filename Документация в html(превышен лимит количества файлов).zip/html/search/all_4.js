var searchData=
[
  ['init_0',['Init',['../class_matrix.html#a81a36e7aa4764ac431f3383736da6a93',1,'Matrix::Init()'],['../class_net_work.html#a7dbf70a9342fde0d9076b6070e7eac2b',1,'NetWork::Init()']]]
];
