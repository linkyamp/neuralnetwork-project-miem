var searchData=
[
  ['data_5finfo_0',['data_info',['../structdata__info.html',1,'']]],
  ['data_5fnetwork_1',['data_NetWork',['../structdata___net_work.html',1,'']]]
];
