var searchData=
[
  ['digit_0',['digit',['../structdata__info.html#ad83071a53fb72c78a8b3bfaf204542b8',1,'data_info']]]
];
