var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_matrix.html#a5acbf9f1ba6d871be2ad3a0cdadf8815',1,'Matrix']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_matrix.html#a0f8f162e6beb0d12bc75c4642471bca9',1,'Matrix']]]
];
