var searchData=
[
  ['pixels_0',['pixels',['../structdata__info.html#a4f3467e8b98c67db4d196df4840f7697',1,'data_info']]]
];
