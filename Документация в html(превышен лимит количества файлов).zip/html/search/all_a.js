var searchData=
[
  ['use_0',['use',['../class_activate_function.html#a1cfd32f9c2131f34aca5a26aab8dc8d9',1,'ActivateFunction']]],
  ['useder_1',['useDer',['../class_activate_function.html#a113acc8d8593872fdff9731ba5350f50',1,'ActivateFunction::useDer(double *value, int n)'],['../class_activate_function.html#a6d671bb3e862ec537144eefde3a156a2',1,'ActivateFunction::useDer(double value)']]]
];
