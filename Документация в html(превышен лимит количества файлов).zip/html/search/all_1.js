var searchData=
[
  ['backpropogation_0',['BackPropogation',['../class_net_work.html#a817b07f408a65b036ce666b493e7f65b',1,'NetWork']]]
];
